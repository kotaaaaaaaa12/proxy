### Code of Conduct

By accessing, using, or contributing to Poke, you agree that all actions, behaviors, and interactions are subject to and governed by the **Poke Project Code of Conduct**, available at:

https://poketube.fun/code-of-conduct

The provisions, standards, and expectations set forth therein apply in full to your use of this service and its related platforms.  
Any breach of these terms may result in limitation or termination of access as outlined in that document. More sections or updates may be introduced in the future without prior notice. Continued use constitutes acceptance of any such changes.

