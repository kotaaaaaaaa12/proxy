# Using too much CPU
Enable hardware acceleration - or alternatively close ambient mode by clicking on the gear icon at the navbar.

# Video lags
Enable hardware acceleration -if it no worky open a issue https://codeberg.org/ashley/poke/issues here :3

# Video not loading 
Try the SD version - if that dont worky um report a issue at https://codeberg.org/ashley/poke/issues :3

# video quailty is low
please open a issue :3 
# RW89DGHRUFURTEJDFMTRF HELLPP POKE IS TOOOOO SLOOW!!
skill issue