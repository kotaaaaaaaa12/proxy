# Poke server is restarting
poke's backend server was probably restarting when you tried to watch a video lol

# Youtube blocked
Youtube blocked poke - this should be temproparary

# backend server is down
the server is just down :D