 const video = require("./src/video.js")
 const channel = require("./src/channel.js")
 const search = require("./src/search.js")

 module.exports = {
   search:search,
   video:video,
   channel:channel
}

