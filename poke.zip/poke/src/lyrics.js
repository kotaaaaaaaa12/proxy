const fetch = require("node-fetch");

async function main(e = "", d = "") {
return "none"
}

module.exports = main;
