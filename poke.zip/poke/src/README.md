# What does this files do lol

fetcher.js - the main fetcher code owo <br>
lyrcis.js - fetches lyrics
