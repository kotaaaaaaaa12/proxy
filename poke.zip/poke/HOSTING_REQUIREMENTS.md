Internet: 1GBIT (recommended 5GBIT)

RAM: 2GB

CPU: Any recent one

OS: Microsoft Windows, macOS or GNU/LINUX (doesnt work on "musl" distros ) with systemd or any service manager