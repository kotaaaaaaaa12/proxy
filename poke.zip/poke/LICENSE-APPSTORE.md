The developers are aware that the terms of service that apply to apps distributed via Apple's App Store services and similar app stores may conflict
with rights granted under the Poke license, the GNU General
Public License, version 3.

The copyright holders of the Poke project do not wish this conflict to prevent the otherwise-compliant distribution of derived apps via the App Store and similar app stores.

Therefore, we have committed not to pursue any license
violation that results solely from the conflict between the GNU GPLv3
and the Apple App Store terms of service or similar app stores. In
other words, as long as you comply with the GPL in all other respects,
including its requirements to provide users with source code and the
text of the license, we will not object to your distribution of the
Poke project through the App Store.