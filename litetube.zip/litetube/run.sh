wget https://bootstrap.pypa.io/get-pip.py
python3 get-pip.py
python3 -m pip install yt-dlp flask waitress requests urllib3 timeago
python3 main.py