<h2>This is a frontend made for the Ultraviolet proxy. (BETA)</h2>

# <a href='https://github.com/titaniumnetwork-dev/ultraviolet-node'>View Source</a>
# Installation
You can run this on replit.
<p>
<a href="https://replit.com/github/DazaSeal/Lunanom/"><img src="https://raw.githubusercontent.com/BinBashBanana/deploy-buttons/master/buttons/remade/replit.svg" width="150" height="35"></a>
</p>

# Running on your own machine

```
git clone https://github.com/DazaSeal/Lunanom/
cd Lunanom
git submodule update --init
npm install
npm start
```
# Frontend by DazaSeal
		      
# Backend by <a href="https://github.com/titaniumnetwork-dev">Titanium Network</a> and Abnumality
